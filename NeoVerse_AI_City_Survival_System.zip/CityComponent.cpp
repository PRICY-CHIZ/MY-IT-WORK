#include "CityComponent.h"
#include <iostream>

CityComponent::CityComponent(int id, const std::string& componentName)
    : componentID(id), name(componentName), active(false) {}

CityComponent::~CityComponent() {}

void CityComponent::activate() { active = true; }
void CityComponent::deactivate() { active = false; }

std::string CityComponent::getStatus() const {
    return active ? "ACTIVE" : "INACTIVE";
}

PowerSystem::PowerSystem(int id, const std::string& name, double power)
    : CityComponent(id, name), powerLevel(power) {}

void PowerSystem::supplyPower() {
    std::cout << "PowerSystem supplying power at " << powerLevel << " MW.\n";
}

void PowerSystem::processEvent(const std::string& event) {
    std::cout << "[PowerSystem] Processing: " << event << "\n";
    if (event == "Power failure") powerLevel = 0;
    supplyPower();
}

void PowerSystem::display() const {
    std::cout << "PowerSystem - " << name << " | Status: " << getStatus()
              << " | Power: " << powerLevel << " MW\n";
}

TransportSystem::TransportSystem(int id, const std::string& name, int traffic)
    : CityComponent(id, name), trafficFlow(traffic) {}

void TransportSystem::manageTraffic() {
    std::cout << "TransportSystem managing traffic flow: " << trafficFlow << ".\n";
}

void TransportSystem::processEvent(const std::string& event) {
    std::cout << "[TransportSystem] Processing: " << event << "\n";
    if (event == "Traffic accident" && trafficFlow > 0) trafficFlow--;
    manageTraffic();
}

void TransportSystem::display() const {
    std::cout << "TransportSystem - " << name << " | Status: " << getStatus()
              << " | Traffic flow: " << trafficFlow << "\n";
}

HealthSystem::HealthSystem(int id, const std::string& name, int hospitals)
    : CityComponent(id, name), hospitalCnt(hospitals) {}

void HealthSystem::provideCare() {
    std::cout << "HealthSystem has " << hospitalCnt << " hospitals available.\n";
}

void HealthSystem::processEvent(const std::string& event) {
    std::cout << "[HealthSystem] Processing: " << event << "\n";
    if (event == "Traffic accident" && hospitalCnt > 0) {
        std::cout << "Medical teams are alerted.\n";
    }
    provideCare();
}

void HealthSystem::display() const {
    std::cout << "HealthSystem - " << name << " | Status: " << getStatus()
              << " | Hospitals: " << hospitalCnt << "\n";
}

SecuritySystem::SecuritySystem(int id, const std::string& name, int threat)
    : CityComponent(id, name), threatLevel(threat) {}

void SecuritySystem::monitorCity() {
    std::cout << "SecuritySystem monitoring threat level: " << threatLevel << ".\n";
}

void SecuritySystem::processEvent(const std::string& event) {
    std::cout << "[SecuritySystem] Processing: " << event << "\n";
    if (event == "Network overload") threatLevel++;
    monitorCity();
}

void SecuritySystem::display() const {
    std::cout << "SecuritySystem - " << name << " | Status: " << getStatus()
              << " | Threat level: " << threatLevel << "\n";
}
