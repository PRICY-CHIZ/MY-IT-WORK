# NeoVerse: AI City Survival System

## Requirements
- C++17 compiler (g++, MinGW, or MSYS2)
- Visual Studio Code with the C/C++ extension

## Compile
Open a terminal in this folder and run:

g++ -std=c++17 *.cpp -o NeoVerse

## Run
Windows:
NeoVerse.exe

Linux/macOS:
./NeoVerse

## Sample login credentials
1. Username: admin
   Password: Admin123
   Clearance: High

2. Username: engineer
   Password: Eng123
   Clearance: Medium

## Files
- Engineer.h / Engineer.cpp: Question 1 authentication
- Event.h: Question 3 events
- CityComponent.h / CityComponent.cpp: Question 4 OOP hierarchy
- CityManager.h / CityManager.cpp: Questions 2, 3, 5 and 6
- FileManager.h / FileManager.cpp: Question 7 persistence
- main.cpp: Runs the complete demonstration

## STL containers
- vector: engineers and sensor readings
- list: historical city logs
- queue: normal events (FIFO)
- stack: emergency events (LIFO)

## Generated data files
- engineers.dat
- events.dat
- city_logs.dat
- config.txt
- city_logs.csv

## Big-O summary
- vector indexed access: O(1)
- vector insertion at end: amortized O(1)
- vector erase at beginning: O(n)
- list insertion at end: O(1)
- list traversal: O(n)
- queue push/pop: O(1)
- stack push/pop: O(1)
- find/find_if: O(n)
- sort: O(n log n)
- min_element/max_element: O(n)
- count_if: O(n)
