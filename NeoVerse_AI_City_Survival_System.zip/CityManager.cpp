#include "CityManager.h"
#include <algorithm>
#include <iostream>
#include <numeric>

CityManager::CityManager() {}

CityManager::~CityManager() {
    for (CityComponent* component : components) delete component;
}

void CityManager::addEngineer(const Engineer& engineer) {
    engineers.push_back(engineer);
}

bool CityManager::login(const std::string& username, const std::string& password) const {
    auto it = std::find_if(engineers.begin(), engineers.end(),
        [&](const Engineer& e) {
            return e.getUsername() == username && e.authenticate(password);
        });
    return it != engineers.end();
}

void CityManager::addSensorReading(double value) { sensorReadings.push_back(value); }

void CityManager::removeOldestSensorReading() {
    if (!sensorReadings.empty()) sensorReadings.erase(sensorReadings.begin());
}

void CityManager::displaySensorReadings() const {
    std::cout << "\nSensor readings: ";
    for (double value : sensorReadings) std::cout << value << " ";
    std::cout << "\n";
}

void CityManager::addCityLog(const std::string& log) { cityLogs.push_back(log); }

void CityManager::displayCityLogs() const {
    std::cout << "\nCity logs:\n";
    for (const auto& log : cityLogs) std::cout << "- " << log << "\n";
}

void CityManager::addEvent(const Event& event) { eventQueue.push(event); }

void CityManager::addEmergency(const EmergencyEvent& emergency) {
    emergencyStack.push(emergency);
}

void CityManager::processEvents() {
    std::cout << "\nProcessing event queue (FIFO):\n";
    while (!eventQueue.empty()) {
        Event e = eventQueue.front();
        eventQueue.pop();
        std::cout << "Event " << e.eventID << ": " << e.type
                  << " | " << e.description << "\n";
        processedEvents.push_back(e);
        cityLogs.push_back("Processed event: " + e.type);
    }
}

void CityManager::processEmergency() {
    std::cout << "\nProcessing emergency stack (LIFO):\n";
    while (!emergencyStack.empty()) {
        EmergencyEvent e = emergencyStack.top();
        emergencyStack.pop();
        std::cout << "Emergency " << e.eventID << ": " << e.type
                  << " | Priority: " << e.priority << "\n";
        cityLogs.push_back("Resolved emergency: " + e.type);
    }
}

void CityManager::displayQueues() const {
    std::cout << "The system uses queue<Event> for normal FIFO events "
                 "and stack<EmergencyEvent> for LIFO emergencies.\n";
}

void CityManager::addComponent(CityComponent* component) {
    components.push_back(component);
}

void CityManager::activateComponents() {
    for (auto* component : components) component->activate();
}

void CityManager::demonstratePolymorphism() {
    std::cout << "\nPolymorphism demonstration:\n";
    for (auto* component : components) {
        component->processEvent("Network overload");
        component->display();
    }
}

void CityManager::sortSensorData() {
    std::sort(sensorReadings.begin(), sensorReadings.end());
}

void CityManager::showMinMax() const {
    if (sensorReadings.empty()) {
        std::cout << "No sensor data available.\n";
        return;
    }
    auto minIt = std::min_element(sensorReadings.begin(), sensorReadings.end());
    auto maxIt = std::max_element(sensorReadings.begin(), sensorReadings.end());
    std::cout << "Lowest sensor value: " << *minIt << "\n";
    std::cout << "Highest sensor value: " << *maxIt << "\n";
}

void CityManager::countCriticalAlerts() const {
    int count = std::count_if(processedEvents.begin(), processedEvents.end(),
        [](const Event& e) { return e.priority >= 8; });
    std::cout << "Critical alerts (priority >= 8): " << count << "\n";
}

void CityManager::findEventByType(const std::string& type) const {
    auto it = std::find_if(processedEvents.begin(), processedEvents.end(),
        [&](const Event& e) { return e.type == type; });
    if (it != processedEvents.end())
        std::cout << "Event found: " << it->type << " - " << it->description << "\n";
    else
        std::cout << "Event not found.\n";
}

void CityManager::report() const {
    std::cout << "\n===== SYSTEM REPORT =====\n";
    std::cout << "Total events processed: " << processedEvents.size() << "\n";

    if (!processedEvents.empty()) {
        std::vector<std::string> types;
        for (const auto& e : processedEvents) types.push_back(e.type);

        std::sort(types.begin(), types.end());
        auto last = std::unique(types.begin(), types.end());
        types.erase(last, types.end());

        std::string commonType;
        int highestCount = 0;
        for (const auto& type : types) {
            int c = std::count_if(processedEvents.begin(), processedEvents.end(),
                [&](const Event& e) { return e.type == type; });
            if (c > highestCount) {
                highestCount = c;
                commonType = type;
            }
        }
        std::cout << "Most common emergency/event type: " << commonType << "\n";

        double totalResponse = std::accumulate(
            processedEvents.begin(), processedEvents.end(), 0.0,
            [](double total, const Event& e) { return total + e.responseTime; });

        std::cout << "Average response time: "
                  << totalResponse / processedEvents.size() << " seconds\n";
    } else {
        std::cout << "Most common emergency/event type: N/A\n";
        std::cout << "Average response time: N/A\n";
    }

    double load = sensorReadings.empty() ? 0.0 :
        std::accumulate(sensorReadings.begin(), sensorReadings.end(), 0.0)
        / sensorReadings.size();

    std::cout << "System load summary (average sensor reading): " << load << "\n";
    std::cout << "=========================\n";
}

const std::vector<Engineer>& CityManager::getEngineers() const { return engineers; }
const std::vector<double>& CityManager::getSensorReadings() const { return sensorReadings; }
const std::list<std::string>& CityManager::getCityLogs() const { return cityLogs; }
const std::vector<Event>& CityManager::getProcessedEvents() const { return processedEvents; }

void CityManager::loadEngineer(const Engineer& e) { engineers.push_back(e); }
void CityManager::loadSensorReading(double value) { sensorReadings.push_back(value); }
void CityManager::loadCityLog(const std::string& log) { cityLogs.push_back(log); }
void CityManager::loadProcessedEvent(const Event& e) { processedEvents.push_back(e); }
