#include "FileManager.h"
#include <fstream>
#include <iostream>
#include <sstream>

void FileManager::saveState(const CityManager& city) {
    std::ofstream engineersFile("engineers.dat");
    for (const auto& e : city.getEngineers()) {
        engineersFile << e.getEngineerID() << "|"
                      << e.getUsername() << "|"
                      << e.getEncryptedPassword() << "|"
                      << e.getClearance() << "\n";
    }

    std::ofstream eventsFile("events.dat");
    for (const auto& e : city.getProcessedEvents()) {
        eventsFile << e.eventID << "|"
                   << e.type << "|"
                   << e.description << "|"
                   << e.priority << "|"
                   << e.responseTime << "\n";
    }

    std::ofstream logsFile("city_logs.dat");
    for (double value : city.getSensorReadings())
        logsFile << "SENSOR|" << value << "\n";

    for (const auto& log : city.getCityLogs())
        logsFile << "LOG|" << log << "\n";

    std::cout << "System state saved to engineers.dat, events.dat and city_logs.dat.\n";
}

void FileManager::loadState(CityManager& city) {
    bool loadedSomething = false;

    std::ifstream engineersFile("engineers.dat");
    std::string line;
    while (std::getline(engineersFile, line)) {
        std::stringstream ss(line);
        std::string id, username, encrypted, clearance;
        if (std::getline(ss, id, '|') &&
            std::getline(ss, username, '|') &&
            std::getline(ss, encrypted, '|') &&
            std::getline(ss, clearance)) {
            city.loadEngineer(Engineer::fromStored(id, username, encrypted, clearance));
            loadedSomething = true;
        }
    }

    std::ifstream logsFile("city_logs.dat");
    while (std::getline(logsFile, line)) {
        std::stringstream ss(line);
        std::string kind, value;
        if (std::getline(ss, kind, '|') && std::getline(ss, value)) {
            if (kind == "SENSOR") {
                try {
                    city.loadSensorReading(std::stod(value));
                    loadedSomething = true;
                } catch (...) {}
            } else if (kind == "LOG") {
                city.loadCityLog(value);
                loadedSomething = true;
            }
        }
    }

    std::ifstream eventsFile("events.dat");
    while (std::getline(eventsFile, line)) {
        std::stringstream ss(line);
        std::string id, type, description, priority, response;
        if (std::getline(ss, id, '|') &&
            std::getline(ss, type, '|') &&
            std::getline(ss, description, '|') &&
            std::getline(ss, priority, '|') &&
            std::getline(ss, response)) {
            try {
                city.loadProcessedEvent(Event(
                    std::stoi(id), type, description,
                    std::stoi(priority), std::stod(response)));
                loadedSomething = true;
            } catch (...) {}
        }
    }

    if (loadedSomething)
        std::cout << "Previous system state loaded.\n";
    else
        std::cout << "No previous saved state found. Starting with sample data.\n";
}

void FileManager::exportLogs(const CityManager& city, const std::string& filename) {
    std::ofstream file(filename);
    file << "City Log\n";
    for (const auto& log : city.getCityLogs())
        file << "\"" << log << "\"\n";
    std::cout << "Logs exported to " << filename << "\n";
}

void FileManager::saveConfig() {
    std::ofstream config("config.txt");
    config << "NeoVerse AI City Survival System\n";
    config << "Version=1.0\n";
    config << "NormalEventPolicy=FIFO\n";
    config << "EmergencyPolicy=LIFO\n";
}
