#ifndef CITYMANAGER_H
#define CITYMANAGER_H

#include "Engineer.h"
#include "Event.h"
#include "CityComponent.h"
#include <vector>
#include <list>
#include <queue>
#include <stack>
#include <string>

class CityManager {
private:
    std::vector<Engineer> engineers;
    std::vector<double> sensorReadings;
    std::list<std::string> cityLogs;
    std::queue<Event> eventQueue;
    std::stack<EmergencyEvent> emergencyStack;
    std::vector<Event> processedEvents;
    std::vector<CityComponent*> components;

public:
    CityManager();
    ~CityManager();

    void addEngineer(const Engineer& engineer);
    bool login(const std::string& username, const std::string& password) const;

    void addSensorReading(double value);
    void removeOldestSensorReading();
    void displaySensorReadings() const;
    void displayCityLogs() const;

    void addCityLog(const std::string& log);
    void addEvent(const Event& event);
    void addEmergency(const EmergencyEvent& emergency);
    void processEvents();
    void processEmergency();
    void displayQueues() const;

    void addComponent(CityComponent* component);
    void activateComponents();
    void demonstratePolymorphism();

    void sortSensorData();
    void showMinMax() const;
    void countCriticalAlerts() const;
    void findEventByType(const std::string& type) const;

    void report() const;

    const std::vector<Engineer>& getEngineers() const;
    const std::vector<double>& getSensorReadings() const;
    const std::list<std::string>& getCityLogs() const;
    const std::vector<Event>& getProcessedEvents() const;

    void loadEngineer(const Engineer& e);
    void loadSensorReading(double value);
    void loadCityLog(const std::string& log);
    void loadProcessedEvent(const Event& e);
};

#endif
