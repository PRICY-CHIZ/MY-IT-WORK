#include "CityManager.h"
#include "FileManager.h"
#include <algorithm>
#include <iostream>
#include <limits>
#include <string>

int main() {
    CityManager city;
    FileManager::loadState(city);

    // ---------------- QUESTION 1: ENGINEER LOGIN ----------------
    if (city.getEngineers().empty()) {
        city.addEngineer(Engineer("ENG001", "admin", "Admin123", "High"));
        city.addEngineer(Engineer("ENG002", "engineer", "Eng123", "Medium"));
    }

    std::cout << "========================================\n";
    std::cout << "   NEOVERSE AI CITY SURVIVAL SYSTEM\n";
    std::cout << "========================================\n";

    std::string username, password;
    std::cout << "\nEngineer Login\nUsername: ";
    std::cin >> username;
    std::cout << "Password: ";
    std::cin >> password;

    if (!city.login(username, password)) {
        std::cout << "Login failed. Access denied.\n";
        return 0;
    }
    std::cout << "Login successful. Access granted.\n";

    // ---------------- QUESTION 2: CITY DATA ----------------
    if (city.getSensorReadings().empty()) {
        city.addSensorReading(72.5);
        city.addSensorReading(88.0);
        city.addSensorReading(65.4);
        city.addSensorReading(91.2);
        city.addSensorReading(77.7);
        city.addCityLog("System started.");
        city.addCityLog("Daily sensor readings loaded.");
    }

    city.displaySensorReadings();
    city.removeOldestSensorReading();
    city.displaySensorReadings();
    city.displayCityLogs();

    // ---------------- QUESTION 3: EVENTS ----------------
    city.addEvent(Event(1, "Traffic accident", "Accident at Central Avenue", 7, 12.5));
    city.addEvent(Event(2, "Power failure", "Grid section A failed", 10, 8.0));
    city.addEvent(Event(3, "Weather alert", "Heavy storm approaching", 8, 15.0));
    city.addEvent(Event(4, "Network overload", "City network overloaded", 9, 10.0));

    city.addEmergency(EmergencyEvent(101, "Power failure", 10, "Critical grid failure"));
    city.addEmergency(EmergencyEvent(102, "Network overload", 9, "Network capacity exceeded"));

    city.displayQueues();
    city.processEvents();
    city.processEmergency();

    // ---------------- QUESTION 4: OOP ----------------
    city.addComponent(new PowerSystem(1, "Main Power Grid", 500.0));
    city.addComponent(new TransportSystem(2, "Central Traffic", 80));
    city.addComponent(new HealthSystem(3, "City Hospitals", 5));
    city.addComponent(new SecuritySystem(4, "City Security", 3));

    city.activateComponents();
    city.demonstratePolymorphism();

    // ---------------- QUESTION 5: STL ALGORITHMS ----------------
    city.sortSensorData();
    city.displaySensorReadings();
    city.showMinMax();
    city.countCriticalAlerts();
    city.findEventByType("Power failure");

    // ---------------- QUESTION 6: REPORTS ----------------
    city.report();

    // ---------------- QUESTION 7: FILE HANDLING ----------------
    FileManager::saveState(city);
    FileManager::saveConfig();
    FileManager::exportLogs(city, "city_logs.csv");

    std::cout << "\nProgram completed successfully.\n";
    return 0;
}
