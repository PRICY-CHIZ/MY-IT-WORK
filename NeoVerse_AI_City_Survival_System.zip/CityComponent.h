#ifndef CITYCOMPONENT_H
#define CITYCOMPONENT_H

#include <string>

class CityComponent {
protected:
    int componentID;
    std::string name;
    bool active;

public:
    CityComponent(int id, const std::string& componentName);
    virtual ~CityComponent();

    void activate();
    void deactivate();
    std::string getStatus() const;

    virtual void processEvent(const std::string& event) = 0;
    virtual void display() const = 0;
};

class PowerSystem : public CityComponent {
private:
    double powerLevel;
public:
    PowerSystem(int id, const std::string& name, double power);
    void supplyPower();
    void processEvent(const std::string& event) override;
    void display() const override;
};

class TransportSystem : public CityComponent {
private:
    int trafficFlow;
public:
    TransportSystem(int id, const std::string& name, int traffic);
    void manageTraffic();
    void processEvent(const std::string& event) override;
    void display() const override;
};

class HealthSystem : public CityComponent {
private:
    int hospitalCnt;
public:
    HealthSystem(int id, const std::string& name, int hospitals);
    void provideCare();
    void processEvent(const std::string& event) override;
    void display() const override;
};

class SecuritySystem : public CityComponent {
private:
    int threatLevel;
public:
    SecuritySystem(int id, const std::string& name, int threat);
    void monitorCity();
    void processEvent(const std::string& event) override;
    void display() const override;
};

#endif
