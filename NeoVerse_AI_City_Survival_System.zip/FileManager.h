#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include "CityManager.h"
#include <string>

class FileManager {
public:
    static void saveState(const CityManager& city);
    static void loadState(CityManager& city);
    static void exportLogs(const CityManager& city, const std::string& filename);
    static void saveConfig();
};
#endif
