#include "Engineer.h"
#include <sstream>
#include <iomanip>

Engineer::Engineer() {}

Engineer::Engineer(const std::string& id, const std::string& user,
                   const std::string& password, const std::string& level)
    : engineerID(id), username(user),
      encryptedPassword(encryptPassword(password)), clearance(level) {}

Engineer Engineer::fromStored(const std::string& id, const std::string& user,
                              const std::string& encrypted,
                              const std::string& level) {
    Engineer e;
    e.engineerID = id;
    e.username = user;
    e.encryptedPassword = encrypted;
    e.clearance = level;
    return e;
}

std::string Engineer::getEngineerID() const { return engineerID; }
std::string Engineer::getUsername() const { return username; }
std::string Engineer::getEncryptedPassword() const { return encryptedPassword; }
std::string Engineer::getClearance() const { return clearance; }

std::string Engineer::encryptPassword(const std::string& password) {
    unsigned long long hash = 1469598103934665603ULL;
    for (unsigned char c : password) {
        hash ^= c;
        hash *= 1099511628211ULL;
    }
    std::stringstream ss;
    ss << std::hex << hash;
    return ss.str();
}

bool Engineer::authenticate(const std::string& password) const {
    return encryptedPassword == encryptPassword(password);
}
