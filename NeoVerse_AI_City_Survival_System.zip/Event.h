#ifndef EVENT_H
#define EVENT_H

#include <string>

struct Event {
    int eventID;
    std::string type;
    std::string description;
    int priority;
    double responseTime;

    Event(int id = 0, const std::string& t = "", const std::string& d = "",
          int p = 0, double r = 0.0)
        : eventID(id), type(t), description(d), priority(p), responseTime(r) {}
};

struct EmergencyEvent {
    int eventID;
    std::string type;
    int priority;
    std::string description;

    EmergencyEvent(int id = 0, const std::string& t = "", int p = 0,
                   const std::string& d = "")
        : eventID(id), type(t), priority(p), description(d) {}
};
#endif
