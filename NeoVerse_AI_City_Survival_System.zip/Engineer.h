#ifndef ENGINEER_H
#define ENGINEER_H

#include <string>

class Engineer {
private:
    std::string engineerID;
    std::string username;
    std::string encryptedPassword;
    std::string clearance;

public:
    Engineer();
    Engineer(const std::string& id, const std::string& user,
             const std::string& password, const std::string& level);
    static Engineer fromStored(const std::string& id, const std::string& user,
                               const std::string& encrypted,
                               const std::string& level);

    std::string getEngineerID() const;
    std::string getUsername() const;
    std::string getEncryptedPassword() const;
    std::string getClearance() const;

    bool authenticate(const std::string& password) const;
    static std::string encryptPassword(const std::string& password);
};
#endif
